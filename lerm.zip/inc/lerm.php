<?php

// loader function files
require_once LERM_DIR . 'inc/admin/function-like.php';

require_once LERM_DIR . 'inc/admin/function-login.php';
require_once LERM_DIR . 'inc/admin/function-archives.php';
require_once LERM_DIR . 'inc/admin/function-lazyload.php';
// require_once LERM_DIR . 'inc/admin/function-load-more.php';
require_once LERM_DIR . 'inc/admin/icon-functions.php';
require_once LERM_DIR . 'inc/admin/functions.opengraph.php';
require_once LERM_DIR . 'inc/admin/function-related.php';
require_once LERM_DIR . 'inc/admin/function-grabber-favico.php';
require_once LERM_DIR . 'inc/admin/auth.php';
require_once LERM_DIR . 'inc/functions/functions-layout.php';
// Load the template files
require_once LERM_DIR . 'inc/admin/zh_to_py.php';
